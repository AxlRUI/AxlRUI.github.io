/* A polyfill for browsers that don't support ligatures. */
/* The script tag referring to this file must be placed before the ending body tag. */

/* To provide support for elements dynamically added, this script adds
   method 'icomoonLiga' to the window object. You can pass element references to this method.
*/
(function () {
    'use strict';
    function supportsProperty(p) {
        var prefixes = ['Webkit', 'Moz', 'O', 'ms'],
            i,
            div = document.createElement('div'),
            ret = p in div.style;
        if (!ret) {
            p = p.charAt(0).toUpperCase() + p.substr(1);
            for (i = 0; i < prefixes.length; i += 1) {
                ret = prefixes[i] + p in div.style;
                if (ret) {
                    break;
                }
            }
        }
        return ret;
    }
    var icons;
    if (!supportsProperty('fontFeatureSettings')) {
        icons = {
            'home3': '&#xe900;',
            'house3': '&#xe900;',
            'images': '&#xe901;',
            'pictures': '&#xe901;',
            'headphones': '&#xe91a;',
            'headset': '&#xe91a;',
            'book': '&#xe91b;',
            'read': '&#xe91b;',
            'envelop': '&#xe902;',
            'mail': '&#xe902;',
            'floppy-disk': '&#xe903;',
            'save2': '&#xe903;',
            'database': '&#xe904;',
            'db': '&#xe904;',
            'bubbles': '&#xe905;',
            'comments': '&#xe905;',
            'bubbles3': '&#xe91c;',
            'comments3': '&#xe91c;',
            'hour-glass': '&#xe906;',
            'loading': '&#xe906;',
            'equalizer': '&#xe907;',
            'sliders': '&#xe907;',
            'aid-kit': '&#xe908;',
            'health': '&#xe908;',
            'shield': '&#xe909;',
            'security': '&#xe909;',
            'list2': '&#xe90a;',
            'todo2': '&#xe90a;',
            'menu': '&#xe90b;',
            'list3': '&#xe90b;',
            'menu2': '&#xe90c;',
            'options2': '&#xe90c;',
            'menu3': '&#xe90d;',
            'options3': '&#xe90d;',
            'menu4': '&#xe90e;',
            'options4': '&#xe90e;',
            'circle-up': '&#xe90f;',
            'up3': '&#xe90f;',
            'circle-right': '&#xe910;',
            'right5': '&#xe910;',
            'circle-down': '&#xe911;',
            'down3': '&#xe911;',
            'circle-left': '&#xe912;',
            'left5': '&#xe912;',
          '0': 0
        };
        delete icons['0'];
        window.icomoonLiga = function (els) {
            var classes,
                el,
                i,
                innerHTML,
                key;
            els = els || document.getElementsByTagName('*');
            if (!els.length) {
                els = [els];
            }
            for (i = 0; ; i += 1) {
                el = els[i];
                if (!el) {
                    break;
                }
                classes = el.className;
                if (/icon-/.test(classes)) {
                    innerHTML = el.innerHTML;
                    if (innerHTML && innerHTML.length > 1) {
                        for (key in icons) {
                            if (icons.hasOwnProperty(key)) {
                                innerHTML = innerHTML.replace(new RegExp(key, 'g'), icons[key]);
                            }
                        }
                        el.innerHTML = innerHTML;
                    }
                }
            }
        };
        window.icomoonLiga();
    }
}());
